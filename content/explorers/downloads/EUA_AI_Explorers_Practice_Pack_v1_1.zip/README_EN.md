# AI Explorers practice pack

Open START_EN.html in a browser. No installation is required. Use the four lab prompts with the supplied fictional files. Answers are supplied so you can check the output independently. Open AI_Cost_Workbook.xlsx and change yellow inputs; all example rates are hypothetical.

The catalogue provides planning estimates, not tested completion times. The tool CSV has blank review dates until an editor verifies a particular entry. To update the local directory, edit its CSV or regenerate the HTML through the academy’s normal publishing workflow. Nothing is published automatically.

Author: Nairi Baghdasaryan, PhD
EUA AI Academy | Edition 1.1
