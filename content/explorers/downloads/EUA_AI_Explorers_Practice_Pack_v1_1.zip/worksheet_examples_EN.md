## 1

Completed example (teaching data): compare Tool A and Tool B on Notice v2. Weights: task quality 40%, sources 20%, privacy 15%, accessibility 10%, integration 5%, cost 5%, continuity 5%. Scores A = 4,4,4,3,3,4,3 and B = 3,4,4,4,3,5,3 on a 1-5 scale. Weighted scores: A 3.80, B 3.55. A remains a candidate only if the required date, fee, and capacity checks all pass. These are hypothetical scores, not ratings of named products.

## 2

Completed example: V1 asked for an announcement and included a fabricated deadline. V2 required source-only extraction; the deadline became “not specified”. Keep input Notice v2 fixed. Record your actual tool/model/date and the observed result. Select V2 only after checking all six fields. The supplied example illustrates the log format, not an empirical benchmark.

## 3

Completed example: 2,000 input and 500 output tokens at $2/$8 per million = $0.008 per attempt. With 1,200 monthly attempts, API cost = $9.60. Including $400 review and $20 fees gives $429.60, or $0.4522 per 950 accepted outputs. Edit AI_Cost_Workbook.xlsx for the live calculation.

## 4

Completed example: wrong deadline; likelihood 3/5, impact 3/5; control = source-only field extraction and coordinator approval; owner = workshop coordinator; residual likelihood 1/5, impact 3/5. These are subjective teaching estimates, not measured probabilities. Test the control using the flawed announcement before lowering the residual estimate.

## 5

Completed example: task = workshop notice rewrite; data = fictional Notice v2; AI contribution = initial extraction and draft; human contribution = checked six fields, removed unsupported deadline, approved wording; tool/model/date = fill from the actual run; limit = no independent confirmation outside supplied source; responsible person = person approving the final version.

## 6

Completed example: user = workshop coordinator; problem = inconsistent notices; input = approved Notice v2; workflow = extract, draft, compare, approve; success = six fields correct with zero invented facts; failure = unsupported field; response = reject draft and re-extract; owner = coordinator; review date = next source update. This worksheet is optional and does not add a project chapter.