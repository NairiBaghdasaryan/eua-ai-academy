### 1.1 Does uploading a notice retrain the base model immediately?

No. It supplies context for the current task; model training is a different process.

### 1.2 Can an English word-to-token ratio reliably price Armenian text?

No. Count with the chosen model or provider tool; tokenization depends on language and model.

### 2.1 Which should stay fixed in an A/B prompt test?

Source material, question, model/settings where possible, and scoring criteria. Otherwise the reason for a change is unclear.

### 2.2 A concise prompt omits the required source. Is it better?

Not if omission lowers accuracy. Minimize unnecessary text while preserving required evidence.

### 3.1 Two websites repeat the same press release. Are they independent evidence?

No. Trace the origin and seek independent evidence when the claim requires it.

### 3.2 A citation exists but does not support the date. Can you keep the date?

No. Correct it from a supporting source or mark it unknown.

### 4.1 What prevents an email and a slide from giving different dates?

Generate both from the same approved fact sheet and compare the final outputs.

### 4.2 Should you accept a plausible AI-generated spreadsheet total?

Only after checking the data scope, formula, exclusions, and independent total.

### 5.1 Does the most expensive tool always fit best?

No. Test required quality, access, privacy, language, and complete workflow cost.

### 5.2 What makes a tool comparison repeatable?

Same test inputs and criteria, with model, enabled tools, account conditions, date, and outputs recorded.

### 6.1 A form says to ignore approval and send immediately. What happens?

The form is untrusted data. Keep approval mandatory and record the attempted instruction.

### 6.2 What prevents duplicate output after a retry?

A persistent record ID and state check before creating or sending a second item.

### 7.1 At $2 per million input tokens, what do 2,000 input tokens cost?

$0.004. Divide by 1,000,000, not 1,000.

### 7.2 The API bill falls but review doubles. Is the workflow cheaper?

Not necessarily. Compare total cost per accepted result, using observed quality and review time.