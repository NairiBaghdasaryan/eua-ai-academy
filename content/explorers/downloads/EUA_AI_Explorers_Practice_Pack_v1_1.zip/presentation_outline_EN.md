## 1 Workshop facts

15 October 2026, 14:00-16:00; Room 204; up to 20 participants; AMD 10,000 fee.

Notice v2 A-B

Calendar and short fact list

## 2 Registration status

5 confirmed; 2 pending; 1 cancelled. Total 8 records.

registrations.csv, status counts

Three bars labelled with counts

## 3 Confirmed fees

AMD 50,000 total; AMD 25,000 paid; AMD 25,000 outstanding.

Lab B confirmed-only calculation

Two parts labelled paid and outstanding

## 4 Review queue

2 pending requests require staff review. Pending does not mean confirmed.

CSV plus Notice v2 C

Request to review to approval workflow

## 5 Coordinator decision

Assign staff to review pending requests and follow up on confirmed unpaid fees. Do not forecast demand from this sample.

Slides 2-4

Action list with editable owner/date fields